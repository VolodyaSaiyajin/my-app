// eslint-disable-next-line
import React from "react";
import style from './footer.css';

const Footer = () => {
    return (
    <div className="footer">
        <p className="footer__copyrite">Все так называемые права защищены</p>
    </div>
    );
}

export default Footer;